#!/bin/sh
export LIB_NAME=libYourProjectRemoteDevice

# the -f flag is to indicate the deletion of the file if exists
rm -f $LIB_NAME.a

#detail any dependencies your cuda file requires
export INCLUDES="-I /usr/local/include/opencv -I /usr/local/cuda/targets/aarch64-linux/include"
#path to nvcc - cuda compiler
export NVCC_COMPILER=/usr/local/cuda/bin/nvcc
#create objects in your project folder
$NVCC_COMPILER -arch=sm_53 -dc -std=c++14 -D__LINUX__ *.cu $INCLUDES
$NVCC_COMPILER -arch=sm_53 -dlink -std=c++14 *.o -o dlink.o
ld -r *.o -o tempLibObject.o
ar crf $LIB_NAME.a tempLibObject.o
rm -f *.o
#will locate the lib one folder up
mv $LIB_NAME.a ../$LIB_NAME.a

#need to copy this file to the target and let it run there using Remote Pre-Link Event